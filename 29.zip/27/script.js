 function calcular() {
      const ano = parseInt(document.getElementById("ano").value);
      const valor = parseFloat(document.getElementById("valor").value);

      if (isNaN(ano) || isNaN(valor) || ano <= 0 || valor <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos.";
        return;
      }

 let taxa;

      if (ano < 1990) {
        taxa = 0.01;
      } else {
        taxa = 0.015;
      }

      const imposto = valor * taxa;
      document.getElementById("resultado").innerHTML = `Imposto a ser pago: R$ ${imposto.toFixed(2)}`;
    }