
function calcular() {
    const saldo = parsefloat(document.getElementById("saldo").value);
    
    if (insnan(saldo) saldo < 0){
        document.getElementById("resultado").innerHTML = "por favor, insira um saldo válido.";
        return;
    }
    let credito;
    if (saldo >= 0 && saldo <= 200)
    {
        credito = saldo * 0.1; //10% do saldo 
        
    } else if (saldo > 200 && saldo<= 400){
        credito = saldo * 0.2; //20% do saldo 
    }else if (saldo > 400 && saldo <= 600){ 
        credito = saldo *0.3; // 30% do saldo 
    } else {
        credito = saldo * 0.4; // 40% do saldo 
    }

document.getElementById
Id("resultado").innerHTML = 
saldo médio: R$ $ {saldo.ttoFixed(2)}<br>
valor do crédito: R$ $ </br>
{credito.tofixed(2)}
´;}
