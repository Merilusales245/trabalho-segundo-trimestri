
function calcular() {
      const codigo = parseInt(document.getElementById("codigo").value);
      const quantidade = parseInt(document.getElementById("quantidade").value);

      if (isNaN(codigo) || isNaN(quantidade) || quantidade <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos.";
        return;
      }

      let preco;

      switch (codigo) {
        case 100:
          preco = 1.20; // Cachorro Quente
          break;
        case 101:
          preco = 1.30; // Bauru Simples
          break;
        case 102:
          preco = 1.50; // Bauru com Ovo
          break;
        case 103:
          preco = 1.20; // Hamburguer
          break;
        case 104:
 preco = 1.70; // Cheeseburguer
          break;
        case 105:
          preco = 2.20; // Suco
          break;
        case 106:
          preco = 1.00; // Refrigerante
          break;
        default:
          document.getElementById("resultado").innerHTML = "Código inválido.";
          return;
      }
    }
