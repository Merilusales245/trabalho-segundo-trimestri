
function calcular(){
    const salario = parsefloat( document.getElementById("salario").value);
    const cargo = document.getElementById("cargo").value;
    if (isNaN(salario)  salario <=0) {
        document.getElementById("resultado").innerHTML = "por favor, insira um salario valido.";
        return;
    }
    let aumento;

    switch ( cargo){
        case "gerente":
            aumento = 0.10; // 10% de aumento 
            break; case "engeneiro":
            aumento = 0.20; // 20% de aumento 
             break; case "tecnico":
            aumento = 0.30; // 30% de aumento 
             break; default:
            aumento = 0.40; // 40% de aumento para autro cargo
    }
    const novosalario = salario + ( salario * aumento);
    const diferenca = novosalario - salario; 
    document.getElementByIdid("resultado").innerHTML = 
    salario antigo: R$ $ {salario.tofixed(2)}<br>
    novosalario: R$ $n</br>
    {novosalario.tofixed(2)}<br>
    {diferenca.tofixed(2)}</br>
    

    }
