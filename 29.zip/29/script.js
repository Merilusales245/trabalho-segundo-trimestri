
 function calcular() {
      const nivel = parseInt(document.getElementById("nivel").value);
      const aulas = parseInt(document.getElementById("aulas").value);

      if (isNaN(aulas) || aulas <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira uma quantidade de aulas válida.";
        return;
      }
let valorHoraAula;

      switch (nivel) {
        case 1:
          valorHoraAula = 12;
          break;
        case 2:
          valorHoraAula = 17;
          break;
        case 3:
          valorHoraAula = 25;
          break;
      }

      const salario = valorHoraAula * aulas * 4.5;
      document.getElementById("resultado").innerHTML = `Salário: R$ ${salario.toFixed(2)}`;
    }